#!/bin/bash

# Definir variables
BACKUP_DIR="/home/runner/workspace/backup"
LOG_FILE="$BACKUP_DIR/backup.log"
EMAIL="juan@gmail.com"  # Cambia esto por tu dirección de correo
SUBJECT="Respaldo Diario"
DATE=$(date +%Y%m%d)
ZIP_FILE="$BACKUP_DIR/backup_${DATE}.tar.gz"

# Crear el directorio de respaldo si no existe
mkdir -p "$BACKUP_DIR"

# Buscar archivos modificados en las últimas 24 horas
FILES=$(find . -type f -mtime -1 2>/dev/null)

# Convertir la lista en un array
readarray -t FILE_ARRAY <<< "$FILES"

# Verificar si hay archivos para respaldar
if [ ${#FILE_ARRAY[@]} -eq 0 ]; then
  echo "No se encontraron archivos modificados en las últimas 24 horas." | tee -a "$LOG_FILE"
  exit 0
fi

# Crear archivo comprimido
tar -czf "$ZIP_FILE" "${FILE_ARRAY[@]}"

# Registrar el proceso de respaldo
if [ $? -eq 0 ]; then
  echo "$(date) - Respaldo creado exitosamente: $ZIP_FILE" | tee -a "$LOG_FILE"
else
  echo "$(date) - Error al crear el respaldo. Revisa los registros." | tee -a "$LOG_FILE"
  exit 1
fi

# Enviar correo con el archivo comprimido y el log
{
  echo "Subject: $SUBJECT"
  echo "To: $EMAIL"
  echo "MIME-Version: 1.0"
  echo "Content-Type: multipart/mixed; boundary=\"boundary\""
  echo ""
  echo "--boundary"
  echo "Content-Type: text/plain"
  echo ""
  echo "Adjunto encontrarás el respaldo diario y el archivo de registro."
  echo ""
  echo "--boundary"
  echo "Content-Type: application/gzip; name=\"$(basename "$ZIP_FILE")\""
  echo "Content-Disposition: attachment; filename=\"$(basename "$ZIP_FILE")\""
  echo "Content-Transfer-Encoding: base64"
  echo ""
  base64 "$ZIP_FILE"
  echo ""
  echo "--boundary"
  echo "Content-Type: text/plain; name=\"$(basename "$LOG_FILE")\""
  echo "Content-Disposition: attachment; filename=\"$(basename "$LOG_FILE")\""
  echo "Content-Transfer-Encoding: base64"
  echo ""
  base64 "$LOG_FILE"
  echo ""
  echo "--boundary--"
} | 

# Registrar el envío del correo
if [ $? -eq 0 ]; then
  echo "$(date) - Correo enviado exitosamente a $EMAIL" | tee -a "$LOG_FILE"
else
  echo "$(date) - Error al enviar el correo. Revisa los registros." | tee -a "$LOG_FILE"
  exit 1
fi

exit 0