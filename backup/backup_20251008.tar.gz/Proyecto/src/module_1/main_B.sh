#!/bin/bash
# ==========================================
# Script: main_B.sh
# Módulo: module_1
# Creado el: Tue Oct  7 04:08:27 PM UTC 2025
# Descripción: Script principal para module_1
# ==========================================

echo "Ejecutando main_B.sh en module_1"

