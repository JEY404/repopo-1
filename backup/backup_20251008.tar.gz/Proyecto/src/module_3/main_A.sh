#!/bin/bash
# ==========================================
# Script: main_A.sh
# Módulo: module_3
# Creado el: Tue Oct  7 04:08:27 PM UTC 2025
# Descripción: Script principal para module_3
# ==========================================

echo "Ejecutando main_A.sh en module_3"

